export CUDA_VISIBLE_DEVICES=1
logdir=/tmp/textsum/backup/textsum/log_root_cccs_WE_en_RecAtt
mkdir $logdir
export basedir=.
#python $basedir/dataset_preprocessing_cccs_ext.py EN $basedir > $basedir/a.log

#head -n 1 $basedir/result_train_cccs_all.txt  >> $basedir/result_train_cccs_all.txt
#python randomSelection_en.py $basedir

#python data_convert_example.py --command text_to_binary --in_file $basedir/result_train_cccs.txt --out_file $basedir/result_train_cccs.bin
#python data_convert_example.py --command text_to_binary --in_file $basedir/result_test_cccs.txt --out_file   $basedir/result_test_cccs.bin

#python seq2seq_attention_cccs_epoch_1200_test.py  --mode=train   --article_key=article   --abstract_key=abstract --emb_dim=300 --data_path=$basedir/result_train_cccs.bin --test_data_path=$basedir/result_test_cccs.bin  --vocab_path=$basedir/test_vocab_cccs_all  --log_root=$logdir --train_dir=$logdir/train --EPOCHS=1000 --enc_layers=3 --enc_timesteps=600  --dec_timesteps=50 --batch_size=60 --word2vec=we_en.txt



#decoding
python data_convert_example.py --command text_to_binary --in_file $basedir/result_test_cccs_all.txt --out_file   $basedir/result_test_cccs_all.bin

python seq2seq_attention_cccs_epoch_1200_test.py  --mode=decode --article_key=article --abstract_key=abstract --emb_dim=300 --data_path=$basedir/result_test_cccs_all.bin  --vocab_path=$basedir/test_vocab_cccs_all  --log_root=$logdir  --decode_dir=$logdir/decode  --beam_size=25  --enc_layers=3 --enc_timesteps=600  --dec_timesteps=50 --word2vec=$basedir/we_en.txt
