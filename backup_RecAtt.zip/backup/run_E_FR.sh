export CUDA_VISIBLE_DEVICES=3
mkdir textsum/log_root_cccs_WE_fr
#python dataset_preprocessing_gig.py 
#python randomSelection_fr.py
#python data_convert_example.py --command text_to_binary --in_file result_train_giga_fr.txt --out_file result_train_giga_fr.bin
#python data_convert_example.py --command text_to_binary --in_file result_test_giga_fr.txt --out_file   result_test_giga_fr.bin

python seq2seq_attention_cccs_epoch_1200_test.py  --mode=train   --article_key=article   --abstract_key=abstract --emb_dim=300 --data_path=result_train_giga_fr.bin --test_data_path=result_test_giga_fr.bin  --vocab_path=test_vocab_giga  --log_root=textsum/log_root_cccs_WE_fr --train_dir=textsum/log_root_cccs_WE_fr/train --EPOCHS=1000 --enc_layers=3 --enc_timesteps=500  --dec_timesteps=30 --batch_size=100

#--word2vec=./we_fr.txt


#decoding
#python data_convert_example.py --command text_to_binary --in_file result_test_cccs_all_fr.txt --out_file   result_test_cccs_all_fr.bin
#python seq2seq_attention_cccs_epoch_1200_test.py  --mode=decode --article_key=article --abstract_key=abstract --emb_dim=200 --data_path=result_test_cccs_all_fr.bin --vocab_path=test_vocab_cccs_all_fr  --log_root=textsum/log_root_cccs_WE_fr  --decode_dir=textsum/log_root_cccs_WE_fr/decode  --beam_size=25 --enc_layers=3 --enc_timesteps=500  --dec_timesteps=50 --word2vec=./we_fr.txt
