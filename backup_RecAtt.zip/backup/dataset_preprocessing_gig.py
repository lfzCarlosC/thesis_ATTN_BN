# -*- coding: utf-8 -*-
"""Example of Converting TextSum model data.
Usage:
python textsum_data_convert.py --command text_to_binary --in_directories dailymail/stories --out_files dailymail-train.bin,dailymail-validation.bin,dailymail-test.bin --split 0.8,0.15,0.05
python textsum_data_convert.py --command text_to_vocabulary --in_directories cnn/stories,dailymail/stories --out_files vocab
"""
import collections
import struct
import sys
import codecs
import os
from os import listdir
from os.path import isfile, join

from nltk.tokenize import sent_tokenize
from nltk.tokenize import WordPunctTokenizer
from nltk.tokenize import word_tokenize
from nltk.tokenize import TreebankWordTokenizer
import giga

defaultencoding = 'utf-8'
if sys.getdefaultencoding() != defaultencoding:
    reload(sys)
    sys.setdefaultencoding(defaultencoding)

exceptions={}
dicMap={}

#import tensorflow as tf
#from tensorflow.core.example import example_pb2


#FLAGS = tf.app.flags.FLAGS
#tf.app.flags.DEFINE_string('command', 'text_to_binary',
#                           'Either text_to_vocabulary or text_to_binary.'
#                           'Specify FLAGS.in_directories accordingly.')
#tf.app.flags.DEFINE_string('in_directories', '', 'path to directory')
#tf.app.flags.DEFINE_string('out_files', '', 'comma separated paths to files')
#tf.app.flags.DEFINE_string('split', '', 'comma separated fractions of data')

def _text_to_binary(text_directory,  output_filename, split_fractions,randomTime):
  input_directories=[]
  for folder in os.listdir(text_directory): 
      for filename in os.listdir(text_directory+"/"+folder):
          input_directories.append(text_directory+"/"+folder+"/"+filename);

  _convert_files_to_binary(input_directories, output_filename)

def _text_to_vocabulary(base_vocab_filename,result_files,vocabulary_filename, max_words=200000:,choose_base_vocab_filename='no'):
  input_directories=[]
  counter = collections.Counter() 
  if choose_base_vocab_filename == 'yes':
          vocab_file = open(base_vocab_filename,'r');
          for wordString in vocab_file:
              wordString = str.strip(wordString)
              wordEntry=wordString.split(" ")
              counter[wordEntry[0]]=int(wordEntry[1]);

  for result_file in result_files:
    f=codecs.open(result_file)
    for line in f:
      seg=line.split("\t")
      article=seg[0].split("=")[1]
      abstract=seg[1].split("=")[1]
      #article = article.replace("<d> <p> <s> ","")
      #article = article.replace(" </s> <s>","")
      #article = article.replace("</s> </p> </d>","")
      #abstract = abstract.replace("<d> <p> <s>","")
      #abstract = abstract.replace(" </s> <s>","")
      #abstract = abstract.replace("</s> </p> </d>","")
      wordEntry=article.strip().split(" ")
      counter.update(wordEntry)
      wordEntry=abstract.strip().split(" ")
      counter.update(wordEntry)
   
  with open(vocabulary_filename, 'w') as writer:
    for word, count in counter.most_common(max_words - 2):
      writer.write(word + ' ' + str(count) + '\n')

    if '<UNK>' not in counter:
        writer.write('<UNK> 0\n')
    if '<PAD>' not in counter:
        writer.write('<PAD> 0\n')
 
def _text_to_vocabulary_old(base_vocab_filename,text_directories,title_directory, vocabulary_filename, max_words=200000,choose_base_vocab_filename='no'):
  input_directories=[]
  counter = collections.Counter()
  for text_directory in text_directories:
      for filename in os.listdir(text_directory):
          input_directories.append(text_directory+"/"+filename);
  
      text_filenames = _get_filenames(input_directories)
  
      #load base vocab original dictionary and increment counter for words in your corpus
      #reference: https://github.com/tensorflow/models/issues/622
      if choose_base_vocab_filename == 'yes':
          vocab_file = open(base_vocab_filename,'r');
          for wordString in vocab_file:
              wordString = str.strip(wordString)
              wordEntry=wordString.split(" ")
              counter[wordEntry[0]]=int(wordEntry[1]);
  
      for filename in text_filenames:
        with open(filename, 'r') as f:
#result = _get_Text(filename)      
          result = cs._get_Text(filename)
          body = result[1].decode('utf8').replace('\n', ' ').replace('\t', ' ').replace('$$$$$','')
      
          title_array = cs.getTitle(title_directory+"/"+result[0])
      
          for title in title_array:

              title = " ".join(WordPunctTokenizer().tokenize(title))
              document = " ".join(WordPunctTokenizer().tokenize(body))
              title = cs.adjustSingleQuote(title)
              document= cs.adjustSingleQuote(document) 
              #document = f.read()
              articleWords = document.split()
              titleWords = title.split()
              counter.update(articleWords)
              counter.update(titleWords)
  
  with open(vocabulary_filename, 'w') as writer:
    for word, count in counter.most_common(max_words - 2):
      writer.write(word + ' ' + str(count) + '\n')
    
    if '<UNK>' not in counter:
        writer.write('<UNK> 0\n')
    if '<PAD>' not in counter:
        writer.write('<PAD> 0\n')

try: 
  import xml.etree.cElementTree as ET 
except ImportError: 
  import xml.etree.ElementTree as ET 
import sys 

import gzip
def _get_Text(text_path,results):
    #add conversion from giga to text
    text=[]
    try: 
        temp_string = gzip.open(text_path,'r','iso-8859-1').read()

        text=giga.sentence_split(temp_string,results)
        
    except Exception, e: 
        print "Error:cannot parse file:",text_path
        print e
        sys.exit(1) 
    return  text

def _get_filenames(input_directories):
  filenames = []
  for directory_name in input_directories:
    if isfile(directory_name):
        filenames.extend([directory_name] )
    else:
        filenames.extend([join(directory_name, f) for f in listdir(directory_name) if isfile(join(directory_name, f))])
  return filenames

def puredTokenize(text):
  return word_tokenize(text)


def getTitle(path):
    f=codecs.open(path,'r','iso-8859-1');
    strs=""
    for line in f:
        strs = strs+line;
    return strs;

def _convert_files_to_binary(text_filePaths,  output_filename):
  tokenizer=TreebankWordTokenizer().tokenize

  with codecs.open(output_filename, 'w','utf-8') as writer: 
    for text_filePath in text_filePaths:
      results=[]
      _get_Text(text_filePath,results)
      for result in results:
        
        title_content = result[1]
        title_content = title_content.encode('utf-8')
        title_content = str.strip(title_content)
        title_content = title_content.decode('utf-8')
        title_contents= sent_tokenize(title_content)
        tempTitle=' '.join(['<s> ' + " ".join(tokenizer(title_sen.decode('utf-8'))) + ' </s>' for title_sen in title_contents])
        tempTitle = tempTitle.encode('utf-8')
        tempTitle = str.strip(tempTitle)
        tempTitle = tempTitle.decode('utf-8')
        title = '<d> ' + tempTitle + ' </d> '
          
        #get articles
        filename_key=result[0]
        print "=====",result[0]
        body = result[2].replace('\n', ' ').replace('\t', ' ')
        sentences=sent_tokenize(body)
        temp = ' '.join(['<s> ' + " ".join(tokenizer(sentence)) + ' </s>' for sentence in sentences])
        if temp == '' :
          continue
        body = '<d> ' + temp + ' </d> '
        body = "article=" + body + "\tabstract=" + title+  "\tfilename=" + filename_key  + "\tpublisher=AFP"
        writer.write(body+"\n"); 

#train&test
#_text_to_binary("/mount/projekte15/slu/Data/French_Gigaword/gigaword_fre_3/data","result_train_giga_all.txt","",1)
_text_to_vocabulary("vocab",["result_train_giga_fr.txt","result_test_giga_fr.txt"],"test_vocab_giga",choose_base_vocab_filename="no")
