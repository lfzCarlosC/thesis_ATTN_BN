import codecs
import numpy as np
f = codecs.open("result_train_cccs.txt","r")
test_f = codecs.open("result_test_cccs_all.txt","r")
data=[]
target=[]
for line in f:
  item=line.split("\t")
  article=item[0].split("=")[-1]
  data.append(article)
  c=item[-1].split("=")[-1].strip()
  target.append(c)

test_data=[]
test_target=[]
for line in test_f:
  item=line.split("\t")
  article=item[0].split("=")[-1]
  test_data.append(article)
  c=item[-1].split("=")[-1].strip()
  test_target.append(c)

print "load completed....."
from sklearn.feature_extraction.text import CountVectorizer
count_vect = CountVectorizer()
X_train_counts = count_vect.fit_transform(data)
X_train_counts.shape
count_vect.vocabulary_.get(u'algorithm')

from sklearn.feature_extraction.text import TfidfTransformer
tf_transformer = TfidfTransformer(use_idf=False).fit(X_train_counts)
X_train_tf = tf_transformer.transform(X_train_counts)
X_train_tf.shape

tfidf_transformer = TfidfTransformer()
X_train_tfidf = tfidf_transformer.fit_transform(X_train_counts)
X_train_tfidf.shape

from sklearn.naive_bayes import MultinomialNB
clf = MultinomialNB().fit(X_train_tfidf, target)

X_new_counts = count_vect.transform(test_data)
X_new_tfidf = tfidf_transformer.transform(X_new_counts)

predicted = clf.predict(X_new_tfidf)

np.mean(predicted == test_target)

np.exp(X_new_tfidf.todense()[0])

count_vect.vocabulary_["computer"]
