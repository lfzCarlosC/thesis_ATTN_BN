
mkdir backup
cp -r *.py ./backup/
cp -r *.txt ./backup/
cp -r *.sh ./backup/

zip -r backup_RecAtt.zip ./backup/
mv backup_RecAtt.zip ~/models/textsum
rm -rf backup
