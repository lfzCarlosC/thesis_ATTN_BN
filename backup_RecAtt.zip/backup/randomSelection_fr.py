import codecs
import random

lst=range(1,3105063)
read = codecs.open("result_train_giga_fr_all.txt","r")
train=codecs.open("result_train_giga_fr.txt","w")
out = codecs.open("result_test_giga_fr.txt","w")
slic=random.sample(lst,62)
j=0
for i in read:
    j=j+1
    if j in slic:
        out.write(i)
    else:
        train.write(i)

read.close()
out.close()
train.close()
