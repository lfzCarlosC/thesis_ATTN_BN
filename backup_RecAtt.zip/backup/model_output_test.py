import tensorflow as tf
_articles = tf.placeholder(tf.int32,[3,4],name='articles')
index_articles=[tf.unique(x)[0] for x in  tf.unpack(_articles)]
c=[[7.,6.,5.,4.,3.],[4.,5.,6.,7.,8.],[5.,6.,7.,8.,9.]]
a=len(index_articles)
_topk_log_probs, _topk_ids = tf.nn.top_k(
              tf.pack([tf.gather(tf.log(tf.nn.softmax(c[i])),index_articles[i]) for i in range(a)]), 3)
_topk_ids = [tf.gather(index_articles[i],_topk_ids[i]) for i in range(a)] 
_topk_ids =tf.pack(_topk_ids)
sess=tf.Session()
sess.run(_topk_ids,feed_dict={_articles: [[1,2,3,4],[1,2,3,4],[1,2,3,4]]})
