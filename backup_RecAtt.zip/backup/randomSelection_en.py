import codecs
import random
import sys

def main(args):
  basedir=args[0]
  lst=range(1,601)
  read = codecs.open(basedir+"/"+"result_train_cccs_all.txt","r")
  train=codecs.open(basedir+"/"+"result_train_cccs.txt","w")
  out = codecs.open(basedir+"/"+"result_test_cccs.txt","w")
  slic=random.sample(lst,120)
  j=0
  for i in read:
    j=j+1
    if j in slic:
        out.write(i)
    else:
        train.write(i)

  read.close()
  out.close()
  train.close()


if __name__ == "__main__":
   main(sys.argv[1:])
