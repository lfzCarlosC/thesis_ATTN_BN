import networkx as nx
import numpy as np
 
from nltk.tokenize.punkt import PunktSentenceTokenizer
from sklearn.feature_extraction.text import TfidfTransformer, CountVectorizer
 
def textrank(document):
    document=document.replace("<d> <s>","")
    document=document.replace("</s> </d>","")
    sentences=document.split("</s> <s>")
    
    bow_matrix = CountVectorizer().fit_transform(sentences)
    normalized = TfidfTransformer().fit_transform(bow_matrix)
 
    similarity_graph = normalized * normalized.T
 
    nx_graph = nx.from_scipy_sparse_matrix(similarity_graph)
    scores = nx.pagerank(nx_graph)
    return sorted(((scores[i],s) for i,s in enumerate(sentences)),
                  reverse=True)

import codecs
def process(file_path):
    f = codecs.open(file_path,"r")
    for line in f:
      items=line.split("\t")
      article=items[0].split("=")[1]
      sentences=textrank(article)
      print sentences


process("result_test_cccs_all.txt")
