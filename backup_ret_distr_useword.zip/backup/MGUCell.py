from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import math, numpy as np
from six.moves import xrange 
import tensorflow as tf

# from multiplicative_integration import multiplicative_integration, multiplicative_integration_for_multiple_inputs

from tensorflow.python.ops.nn import rnn_cell
import highway_network_modern
from multiplicative_integration_modern import multiplicative_integration
from normalization_ops_modern import layer_norm

from linear_modern import linear

RNNCell = rnn_cell.RNNCell


class MGUCell(RNNCell):
  """Minimal Gated Unit from  http://arxiv.org/pdf/1603.09420v1.pdf."""

  def __init__(self, num_units, use_multiplicative_integration = True,
    use_recurrent_dropout = False, recurrent_dropout_factor = 0.90, is_training = True,
    forget_bias_initialization = 1.0):
    self._num_units = num_units
    self.use_multiplicative_integration = use_multiplicative_integration
    self.use_recurrent_dropout = use_recurrent_dropout
    self.recurrent_dropout_factor = recurrent_dropout_factor
    self.is_training = is_training
    self.forget_bias_initialization = forget_bias_initialization

  @property
  def input_size(self):
    return self._num_units

  @property
  def output_size(self):
    return self._num_units

  @property
  def state_size(self):
    return self._num_units

  def __call__(self, inputs, state, timestep = 0,scope=None):
    with tf.variable_scope(scope or type(self).__name__):       
      with tf.variable_scope("Gates"):  # Forget Gate bias starts as 1.0 -- TODO: double check if this is correct
        if self.use_multiplicative_integration:
          gated_factor = multiplicative_integration([inputs, state], self._num_units, self.forget_bias_initialization)
        else:
          gated_factor = linear([inputs, state], self._num_units, True, self.forget_bias_initialization)

        gated_factor = tf.sigmoid(gated_factor)  

      with tf.variable_scope("Candidate"): 
        if self.use_multiplicative_integration:
          c = tf.tanh(multiplicative_integration([inputs, state*gated_factor], self._num_units, 0.0))
        else:
          c = tf.tanh(linear([inputs, state*gated_factor], self._num_units, True, 0.0))

        if self.use_recurrent_dropout and self.is_training:
          input_contribution = tf.nn.dropout(c, self.recurrent_dropout_factor)
        else:
          input_contribution = c

      new_h = (1 - gated_factor)*state + gated_factor * input_contribution
    return new_h, new_h

