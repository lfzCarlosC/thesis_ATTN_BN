
mkdir backup
cp -r *.py ./backup/
cp -r *.txt ./backup/
cp -r *.sh ./backup/

zip -r backup_ret_distr_useword.zip ./backup/
mv backup_ret_distr_useword.zip ~/models/textsum
rm -rf backup
