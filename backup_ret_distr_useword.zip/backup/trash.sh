learning rate from 0.01 to 0.00001
hidden layer size increase
