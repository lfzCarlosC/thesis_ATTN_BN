export CUDA_VISIBLE_DEVICES=3
logdir=/tmp/textsum/backup/textsum/log_root_cccs_WE_en_fr
mkdir $logdir
export basedir=.
python $basedir/dataset_preprocessing_cccs_ext.py FR $basedir > $basedir/a.log

head -n 1 $basedir/result_train_cccs_all.txt  >> $basedir/result_train_cccs_all_fr.txt
#cp -r result_train_cccs_all.txt  $basedir/
#cat $basedir/result_train_cccs_all.txt | grep "RATP" >> temp1
#shuf -n 40 temp1 > temp2
#cat $basedir/result_train_cccs_all.txt | grep "RATP" >> temp1
#cat $basedir/result_train_cccs_all.txt | grep "RATP" >> temp1
#cat $basedir/result_train_cccs_all.txt | grep "RATP" >> temp1
#cat temp1 >> $basedir/result_train_cccs_all.txt
#cat temp2 >> $basedir/result_train_cccs_all.txt
#rm -rf temp1
#rm -rf temp2

python randomSelection_fr.py $basedir


python data_convert_example.py --command text_to_binary --in_file $basedir/result_train_cccs_fr.txt --out_file $basedir/result_train_cccs_fr.bin
python data_convert_example.py --command text_to_binary --in_file $basedir/result_test_cccs_fr.txt --out_file   $basedir/result_test_cccs_fr.bin

python seq2seq_attention_cccs_epoch_1200_test.py  --mode=train   --article_key=article   --abstract_key=abstract --emb_dim=300 --data_path=$basedir/result_train_cccs_fr.bin --test_data_path=$basedir/result_test_cccs_fr.bin  --vocab_path=$basedir/test_vocab_cccs_all_fr  --log_root=$logdir --train_dir=$logdir/train --EPOCHS=1000 --enc_layers=3 --enc_timesteps=600  --dec_timesteps=50 --batch_size=60 --word2vec=$basedir/we_fr.txt



#decoding
#python data_convert_example.py --command text_to_binary --in_file $basedir/result_test_cccs_all.txt --out_file   $basedir/result_test_cccs_all.bin

#new features
#--use_article_word
#--distraction
##--RecAtt
#python seq2seq_attention_cccs_epoch_1200_test.py  --mode=decode --article_key=article --abstract_key=abstract --emb_dim=300 --data_path=$basedir/result_test_cccs_all.bin  --vocab_path=$basedir/test_vocab_cccs_all  --log_root=$logdir  --decode_dir=$logdir/decode  --beam_size=25  --enc_layers=3 --enc_timesteps=600  --dec_timesteps=50 --use_article_word=0 --use_decoding_distraction=0  --word2vec=$basedir/we_en.txt
