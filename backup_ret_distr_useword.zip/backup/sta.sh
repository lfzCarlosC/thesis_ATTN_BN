cat  result_test_cccs_all.txt | grep "printer" | wc -l
